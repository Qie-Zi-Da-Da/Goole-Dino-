#ifndef HC595_H
#define HC595_H

#include "board.h"

#define SET_DS()  		gpioWrite(PB,2,HIGH)
#define CLR_DS()  		gpioWrite(PB,2,LOW)
#define SHCLK()	  		gpioWrite(PB,1,LOW);  gpioWrite(PB,1,HIGH)
#define SEG_ST_CLK()	gpioWrite(PA,4,LOW);  gpioWrite(PA,4,HIGH)

void hc595Send(uint8_t data);

#endif // HC595_H