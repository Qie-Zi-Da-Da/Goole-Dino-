// ***************     I2C driver V 1.0    ***************
// ***           Written By P. Fletcher-Jones          ***
// ***                Written on 06/6/01			   ***
// ***                 Last MOD 15/11/01			   ***
// ***       Compiled using ImageCraft C Comiler       ***
// *******************************************************

// ****************************** //
// *** I2C Hardware Interface *** //
// ****************************** //

#define SDA_PIN 1
#define SDA_DIR DDRD
#define SDA_PORT PORTD
#define SDA_PINREG PIND

#define SCL_PIN 0
#define SCL_DIR DDRD
#define SCL_PORT PORTD

#define EEPROM_BUS_ADDRESS 0xa0

// 读取SDA引脚的输入状态
#define SDA_Input (SDA_PINREG & BIT(SDA_PIN))

// 设置SCL引脚输出为低电平
#define SCL_OutputLow cbi(SCL_PORT, SCL_PIN)
// 设置SDA引脚输出为低电平
#define SDA_OutputLow cbi(SDA_PORT, SDA_PIN)

// 设置SCL引脚输出为高电平
#define SCL_Hight cbi(SCL_DIR, SCL_PIN)
// 设置SCL引脚输出为低电平
#define SCL_Low sbi(SCL_DIR, SCL_PIN)
// 设置SDA引脚输出为高电平
#define SDA_Hight cbi(SDA_DIR, SDA_PIN)
// 设置SDA引脚输出为低电平
#define SDA_Low sbi(SDA_DIR, SDA_PIN)
// 等待I2C总线空闲
#define I2C_Delay \
    NOP();        \
    NOP();        \
    NOP();        \
    NOP();        \
    NOP();        \
    NOP();        \
    NOP();        \
    NOP();        \
    NOP();        \
    NOP();        \
    NOP();        \
    NOP();        \
    NOP();        \
    NOP();        \
    NOP();        \
    NOP();

// 写入EEPROM
void eeprom_write(unsigned int address, unsigned char data);
// 读取EEPROM
unsigned char eeprom_read(unsigned int address);
// 连续读取EEPROM
void eeprom_multi_read(unsigned int address, unsigned char *data, unsigned char len);
// 连续写入EEPROM
void eeprom_multi_write(unsigned int address, unsigned char *data, unsigned char len);



// 初始化I2C总线
void I2C_init(void);
// 启动I2C总线
unsigned char I2C_start(void);
// 停止I2C总线
void I2C_stop(void);
// 读取I2C总线数据
unsigned char I2C_read(unsigned char ack);
// 写入I2C总线数据
unsigned char I2C_write(unsigned char c);