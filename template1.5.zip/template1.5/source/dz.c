#include "dz.h"

void segSelect(char index)
{
	PORTA &= 0xf0;
	PORTA |= index;
}

int segIndex, dzIndex;

void dzDisplay(void)
{
	gpioWrite(dz595_OE_port, dz595_OE_pin, HIGH);
	
	spitransferByte(zdhz[1][ dzIndex + 16]);
	spitransferByte(zdhz[1][ dzIndex]);
	spitransferByte(zdhz[0][ dzIndex + 16]);
	spitransferByte(zdhz[0][ dzIndex]);

	gpioWrite(dz595_ST_port, dz595_ST_pin, LOW);
	gpioWrite(dz595_ST_port, dz595_ST_pin, HIGH);
	segSelect(dzIndex);
	gpioWrite(dz595_OE_port, dz595_OE_pin, LOW);
	dzIndex++;
	if (dzIndex > 15)
		dzIndex = 0;
}

void segDisplay(void)
{
	gpioWrite(seg595_OE_port, seg595_OE_pin, HIGH);

	spitransferByte(seg7Code[Disp_data[segIndex]]);

	gpioWrite(seg595_ST_port, seg595_ST_pin, LOW);
	gpioWrite(seg595_ST_port, seg595_ST_pin, HIGH);
	segSelect(segIndex);
	gpioWrite(seg595_OE_port, seg595_OE_pin, LOW);
	segIndex++;
	if (segIndex > 7)
		segIndex = 0;
}