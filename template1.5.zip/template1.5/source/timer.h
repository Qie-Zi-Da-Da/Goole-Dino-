
#ifndef __TIMER_H
#define __TIMER_H 1
#include "board.h"


#define time_after(a, b) ((S16)((S16)(b) - (S16)(a)) < 0)
// 计算延时msDelay，以ms为单位
#define Timer_PassedDelay(startTime, msDelay) (time_after(Timer_GetTickCount(), (startTime + msDelay)))
// 计算两个时间的时间差，返回一个整数
#define interval(a, b) ((S16)((S16)(b) - (S16)(a))) // systick decount

// 获取当前系统时间，返回一个整数
#define Timer_GetTickCount() (systick_ms)

// 初始化定时器0，用于计算系统时间
void timer0_init(void);
// 全局变量，用于存储系统时间
extern int systick_ms;

#endif