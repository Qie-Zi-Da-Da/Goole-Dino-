#include "hc595.h"

void hc595Send(uint8_t data)
{
	int posit;
	for(posit=0; posit<8; posit++)
	{
		if (data&BIT(posit)) {
      		SET_DS();
    	} else {
      		CLR_DS();		
    	}
		SHCLK();
	}
	SEG_ST_CLK();    
}