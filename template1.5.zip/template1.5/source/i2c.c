
#include <iom2560v.h>
#include <stdio.h>
#include <ASSERT.H>

#include "board.h"

#define EEPROM_BUS_ADDRESS 0xa0
#define LM75_ADDRESS   0x92

#define SCL_Hight DDRD &= ~(1 << 0)
#define SCL_Low DDRD |= (1 << 0)
#define SDA_Hight DDRD &= ~(1 << 1)
#define SDA_Low DDRD |= (1 << 1)
#define SDA_Input (PIND & (1 << 1))

#define Page_MaxSize 64

#define Delay_1us \
  NOP();          \
  NOP();          \
  NOP();          \
  NOP();          \
  NOP();          \
  NOP();          \
  NOP()
#define I2C_Delay \
  Delay_1us;      \
  Delay_1us;    \
  Delay_1us;    \
  Delay_1us     \
  Delay_1us


void delay_ms(int count)
{
  int i;
  while (count--)
  {
    for (i = 0; i < 187 * 8; i++)
    {
      NOP();
    }
  }
}

void I2C_init(void)
{
  PORTD &= ~(1 << 1);
  PORTD &= ~(1 << 0);
  SCL_Low;
  SDA_Low;
}

//generate start
unsigned char I2C_start(void)
{
  SDA_Hight;
  I2C_Delay;
  SCL_Hight;
  I2C_Delay;
  SDA_Low;
  I2C_Delay;
  SCL_Low;
  I2C_Delay;
  return 1;
}

void I2C_stop(void)
{
  SDA_Low;
  I2C_Delay;
  SCL_Hight;
  I2C_Delay;
  SDA_Hight;
  I2C_Delay;
}

//write one byte, and return whether there is an ACK
unsigned char I2C_write(unsigned char c)
{
  unsigned char i, ack = 1;
  for (i = 0; i < 8; i++)
  {
    if (c & 0x80)
      SDA_Hight;
    else
      SDA_Low;
    SCL_Hight;
    I2C_Delay;
    SCL_Low;
    c <<= 1;
    I2C_Delay;
  }
  SDA_Hight;
  I2C_Delay;
  SCL_Hight;
  I2C_Delay;
  if (SDA_Input)
    ack = 0; //ʧ��
  SCL_Low;
  I2C_Delay;
  return ack;
}

//read one byte, 1: ack��0: nack
unsigned char I2C_read(unsigned char ack)
{
  unsigned char i, ret=0;
  SDA_Hight;
  for (i = 0; i < 8; i++)
  {
    I2C_Delay;
    SCL_Low;
    I2C_Delay;
    SCL_Hight;
    I2C_Delay;
    ret <<= 1;
    if (SDA_Input)
      ret++;
  }
  SCL_Low;
  I2C_Delay;
  if (ack) 
    SDA_Low;
  else 
    SDA_Hight;
  I2C_Delay;
  SCL_Hight;
  I2C_Delay;
  SCL_Low;
  I2C_Delay;
  return (ret);
}
// unsigned char eeprom_read(unsigned int address)
// {
//      unsigned char temp;
//      I2C_start();
// 	 I2C_write(0xA0);
// 	 I2C_write(address>>8);
// 	 I2C_write(address&0x00FF);
// 	 I2C_start();
// 	 I2C_write(0xA1);
// 	 temp=I2C_read(0);
// 	 return temp;
// }

// void eeprom_write(unsigned int address, unsigned char data)
// {
//      I2C_start();
// 	 I2C_write(0xA0);
// 	 I2C_write(address>>8);
// 	 I2C_write(address&0x00FF);
// 	 I2C_write(data);
// 	 I2C_stop();
// 	 delay_ms(5);
// }

void eeprom_write(unsigned int address, unsigned int data)
{
   I2C_start();
   I2C_write(0xA0);
   I2C_write(address>>8);
   I2C_write(address&0x00FF);
   I2C_write(data>>8);
   I2C_write(data&0x00FF);
   I2C_stop();
   delay_ms(5);
}

unsigned int eeprom_read(unsigned int address)
{
  unsigned char High,Low;
  I2C_start();
  I2C_write(0xA0);
  I2C_write(address>>8);
  I2C_write(address&0x00FF);
  I2C_start();
  I2C_write(0xA1);
  High=I2C_read(1);
  Low=I2C_read(0);
  I2C_stop();
  delay_ms(5);
  return (High<<8)|Low;
}



void eeprom_multi_read(U16 address, U8 length, U8 *pdata)
{
     unsigned char i;
     I2C_start();
	 I2C_write(0xA0);
	 I2C_write(address>>8);
	 I2C_write(address&0x00FF);
	 I2C_start();
	 I2C_write(0xA1);
	 for(i=0;i<length-1;i++)
	 {
	   *pdata = I2C_read(1);
	    pdata++;
	 }
	 *pdata=I2C_read(0);  
}

void eeprom_multi_write(U16 address, U8 *pdata, U8 length)
{
     unsigned char i;
     I2C_start();
	 I2C_write(0xA0);
	 I2C_write(address>>8);
	 I2C_write(address&0x00FF);
	 for(i=0;i<length-1;i++)
	 {
	    I2C_write(*pdata);
	    pdata++;
	 } 
	 I2C_stop();
	 delay_ms(5);
}