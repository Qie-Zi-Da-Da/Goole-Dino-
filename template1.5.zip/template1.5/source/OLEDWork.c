#include "OLEDWork.h"
#include "oldfont.h"
#include "board.h"
#include "Delay.h"
#include "time.h"
#include "board.h"
#include "key.h"
#include "queue.h"
//#include "oledfont.h"

/****************** �²˵���� ********************/
	uint16_t Hs;//��߷�
uint16_t score;//��ǰ����
uint16_t obstacle_ran;//���ֲ�ﳤ��
uint16_t height;//������Ծ�߶�
uint8_t Menufalg;//�˵���־λ
uint8_t MenuSelect;//�˵�ѡ��λ
uint8_t MenuShow=0;//�˵���ʾ��־λ
uint8_t reset;//���ñ�־λ
uint8_t obstacle_length;//ֲ�ﳤ��
uint8_t bmpflag;//��ʾͼƬ��־λ
uint8_t playflag;//��Ϸ���˵���־λ
uint8_t menuclear;//�˵�����
uint8_t ClearF;//������־λ
uint8_t beingspeed;//��Ϸ��ʼ�ٶ�
uint8_t mode;//�˵�ģʽ
uint8_t Key4;//��KeyNum=4�İ��´���
uint8_t speedmax=36;//�ٶ����ֵ
uint8_t FMQswitch;//����������
uint8_t KeyNum;//����ֵ
uint8_t t;//�������
uint8_t roll;
uint8_t Speed;//��Ϸ�ٶ�
uint8_t deadflag;//������־λ
uint8_t begingtemp;//��ʼ�ٶ��м����
uint8_t speedtep=9;//����ٶ��м����
uint8_t Settlement;//���㶯����־λ
/****************************************************/



#if OLED_MODE == 1

void OLED_WR_Byte(u8 dat, u8 cmd)
{
	DATAOUT(dat);
	if (cmd)
		OLED_DC_Set();
	else
		OLED_DC_Clr();
	OLED_CS_Clr();
	OLED_WR_Clr();
	OLED_WR_Set();
	OLED_CS_Set();
	OLED_DC_Set();
}
#else

void OLED_WR_Byte(u8 dat, u8 cmd)
{
	u8 i;
    GID;
	if (cmd)
	{
		OLED_DC_Set();
	}
	else if (cmd != 1)
	{
		OLED_DC_Clr();
	}
	OLED_CS_Clr();
	spitransferByte(dat);
	OLED_CS_Set();
	OLED_DC_Set();
    GIE;
}
#endif

/* 9.28 ���ΰ ���� OLEDд���� */
void OLED_Write_Data(uint8_t Data)
{
	OLED_WR_Byte(Data,OLED_DATA);
	// OLED_I2C_Start();
	// OLED_I2C_SendByte(0x78);		
	// OLED_I2C_SendByte(0x40);		
	// OLED_I2C_SendByte(Data); 
	// OLED_I2C_Stop();
}
void OLED_Set_Pos(unsigned char x, unsigned char y)
{
	OLED_WR_Byte(0xb0 + y, OLED_CMD);
	OLED_WR_Byte(((x & 0xf0) >> 4) | 0x10, OLED_CMD);
	OLED_WR_Byte((x & 0x0f), OLED_CMD);
}

/* 9.28 ���ΰ ���� ���ù��λ�ã��ض��壩 */
void OLED_SetCursor(uint8_t y,uint8_t x)	
{
	OLED_Set_Pos(x, y);//��תһ��X��Y
	// OLED_Write_Command(0xB0|y);
	// OLED_Write_Command(0x10|((x&0xF0)>>4));
	// OLED_Write_Command(0x00|((x&0x0F)));
}

void OLED_Display_On(void)
{
	OLED_WR_Byte(0X8D, OLED_CMD); // SET DCDC
	OLED_WR_Byte(0X14, OLED_CMD); // DCDC ON
	OLED_WR_Byte(0XAF, OLED_CMD); // DISPLAY ON
}

void OLED_Display_Off(void)
{
	OLED_WR_Byte(0X8D, OLED_CMD); // SET DCDC
	OLED_WR_Byte(0X10, OLED_CMD); // DCDC OFF
	OLED_WR_Byte(0XAE, OLED_CMD); // DISPLAY OFF
}
//????,???,????????!??????!!!	
void OLED_Clear(void)
{
	u8 i, n;
	for (i = 0; i < 8; i++)
	{
		OLED_WR_Byte(0xb0 + i, OLED_CMD); //??????0~7?
		OLED_WR_Byte(0x00, OLED_CMD);	  //???????????
		OLED_WR_Byte(0x10, OLED_CMD);	  //???????????   
		for (n = 0; n < 128; n++)
			OLED_WR_Byte(0, OLED_DATA);
	}//????
}

//???????????,??????
//x:0~127
//y:0~63
//mode:0,????;1,????				 
//size:???? 16/12 
void OLED_ShowChar(u8 x, u8 y, u8 chr)
{
	unsigned char c = 0, i = 0;
	c = chr - ' '; //???????	
	if (x > Max_Column - 1)
	{
		x = 0;
		y = y + 2;
	}
	if (SIZE == 16)
	{
		OLED_Set_Pos(x, y);
		for (i = 0; i < 8; i++)
			OLED_WR_Byte(F8X16[c * 16 + i], OLED_DATA);
		OLED_Set_Pos(x, y + 1);
		for (i = 0; i < 8; i++)
			OLED_WR_Byte(F8X16[c * 16 + i + 8], OLED_DATA);
	}
	else
	{
		OLED_Set_Pos(x, y + 1);
		for (i = 0; i < 6; i++)
			OLED_WR_Byte(F6x8[c][i], OLED_DATA);
	}
}
//m^n??
u32 oled_pow(u8 m, u8 n)
{
	u32 result = 1;
	while (n--)
		result *= m;
	return result;
}
//??2???
//x,y :????	 
//len :?????
//size:????
//mode:??	0,????;1,????
//num:??(0~4294967295);	

void OLED_ShowNum(u8 x, u8 y, u32 num, u8 len, u8 size2)
{
	u8 t, temp;
	u8 enshow = 0;
	for (t = 0; t < len; t++)
	{
		temp = (num / oled_pow(10, len - t - 1)) % 10;
		if (enshow == 0 && t < (len - 1))
		{
			if (temp == 0)
			{
				OLED_ShowChar(x + (size2 / 2) * t, y, ' ');
				continue;
			}
			else
				enshow = 1;
		}
		OLED_ShowChar(x + (size2 / 2) * t, y, temp + '0');
	}
}

void OLED_ShowString(u8 x, u8 y, u8 *chr)
{
	unsigned char j = 0;
	while (chr[j] != '\0')
	{
		OLED_ShowChar(x, y, chr[j]);
		x += 8;
		if (x > 120)
		{
			x = 0;
			y += 2;
		}
		j++;
	}
}

/*********** 9.28 ���ΰ ���� OLED��ʾ���ִ�С�ַ���,mode��ʾ������ʾ *************/
void OLED_ShowString_new(uint8_t Line,uint8_t Column,uint8_t *String,uint8_t size,uint8_t mode)
{
	switch(size)
	{
		case 1:Line%=9;Column%=22;if(!Column)Column=1;OLED_6x8String(Line,Column,String,mode);break;//oledfoth.h
		case 2:Line%=5;Column%=22;if(!Line)Line=1;if(!Column)Column=1;OLED_6x12String(Line,Column,String,mode);break;	
		case 3:Line%=5;Column%=17;if(!Line)Line=1;if(!Column)Column=1;OLED_8x16String(Line,Column,String,mode);break;
		case 4:Line%=7;Column%=11;if(!Line)Line=1;if(!Column)Column=1;OLED_12x24String(Line,Column,String,mode);break;	
		default:Line%=7;Column%=11;if(!Line)Line=1;if(!Column)Column=1;OLED_12x24String(Line,Column,String,mode);OLED_12x24String(Line,Column,String,mode);break;
	}
}
/****************************************************************************************************/

void OLED_ShowCHinese(u8 x, u8 y, u8 no)
{
	u8 t, adder = 0;
	OLED_Set_Pos(x, y);
	for (t = 0; t < 16; t++)
	{
		OLED_WR_Byte(Hzk[2 * no][t], OLED_DATA);
		adder += 1;
	}
	OLED_Set_Pos(x, y + 1);
	for (t = 0; t < 16; t++)
	{
		OLED_WR_Byte(Hzk[2 * no + 1][t], OLED_DATA);
		adder += 1;
	}
}

/* 9.28 ���ΰ ���� OLED��ʾOLED��ʾ�˵�����,mode��ʾ������ʾ*///ShowCh
void OLED_ShowChinese(uint8_t Line,uint8_t Column,uint8_t n,uint8_t mode)//OLED��ʾ����,mode��ʾ������ʾ
{
		uint8_t i,j,u=0;
		for(i=0;i<2;i++)
		{	
			OLED_SetCursor(Line*2-2+i,Column*16-16);
			for(j=0;j<16;j++)
			{
				if(mode==0)
				{
				OLED_Write_Data(ChineseFont[n][u]);
				u++;
				}
				else
				{
				OLED_Write_Data(~ChineseFont[n][u]);
				u++;
				}
		}		
	}
}

void OLED_ShowMenuChinese(uint8_t Line,uint8_t Column,uint8_t n,uint8_t mode)
{
	uint8_t i,j,u=0;
	
		for(i=0;i<2;i++)
		{	
			OLED_SetCursor(Line*2-2+i,Column*16-16);
			for(j=0;j<16;j++)
			{
				if(mode==0)
				{
				OLED_Write_Data(ChineseMenu[n][u]);//oledfoth.h
				u++;
				}
				else
				{
				OLED_Write_Data(~ChineseMenu[n][u]);
				u++;
				}
		}		
	}
}
/*********************************************************************************************/


/***********?????????BMP??128?64?????(x,y),x???0?127?y?????0?7*****************/
void OLED_DrawBMP(unsigned char x0, unsigned char y0, unsigned char x1, unsigned char y1, unsigned char BMP[])
{
	unsigned int j = 0;
	unsigned char x, y;

	if (y1 % 8 == 0)
		y = y1 / 8;
	else
		y = y1 / 8 + 1;
	for (y = y0; y < y1; y++)
	{
		OLED_Set_Pos(x0, y);
		for (x = x0; x < x1; x++)
		{
			OLED_WR_Byte(BMP[j++], OLED_DATA);
		}
	}
}

// ??????
void OLED_DrawBMPFast(const unsigned char BMP[])
{
	unsigned int j = 0;
	unsigned char x, y;

	for (y = 0; y < 8; y++)
	{
		OLED_Set_Pos(0, y);
		for (x = 0; x < 128; x++)
		{
			OLED_WR_Byte(BMP[j++], OLED_DATA);
		}
	}
}

// ????
void oled_drawbmp_block_clear(int bx, int by, int clear_size)
{
	unsigned int i;
	OLED_Set_Pos(bx, by);

	for (i = 0; i < clear_size; i++)
	{
		if (bx + i>128) break;
		OLED_WR_Byte(0x00, OLED_DATA);
	}
}

// ????
void OLED_DrawGround()
{
	// ??????
	static unsigned int pos = 0;
	// ??????
	unsigned char speed = 5;
	// ??????
	unsigned int ground_length = sizeof(GROUND);
	// ??x??
	unsigned char x;

    // ????
    OLED_Set_Pos(0, 7);
	// ??????
	for (x = 0; x < 128; x++)
	{
		// ????
		OLED_WR_Byte(GROUND[(x + pos) % ground_length], OLED_DATA);
	}

	// ????
	pos = pos + speed;
	// ????????????????
	if(pos>ground_length) pos=0;
}
// ????
void OLED_DrawCloud()
{
	static int pos = 128;
	static char height=0;
	char speed = 3;
	unsigned int i=0;
	int x;
	int start_x = 0;
	int length = sizeof(CLOUD);
	unsigned char byte;

	//if (pos + length <= -speed) pos = 128;

	if (pos + length <= -speed)
	{
		pos = 128;
		height = rand()%4;
	}
	if(pos < 0)
	{
		start_x = -pos;
		OLED_Set_Pos(0, 1+height);
	}
	else
	{
		OLED_Set_Pos(pos, 1+height);
	}

    
	for (x = start_x; x < length + speed; x++)
	{
		if (pos + x > 127) break;
		if (x < length) byte = CLOUD[x];
		else byte = 0x0;
		OLED_WR_Byte(byte, OLED_DATA);
	}

	pos = pos - speed;
}

// ?????
void OLED_DrawDino()
{
	static unsigned char dino_dir = 0;
	unsigned int j=0;
	unsigned char x, y;
	unsigned char byte;

	dino_dir++;
	dino_dir = dino_dir%2;
	for(y=0; y<2; y++)
	{
		OLED_Set_Pos(16, 6+y);
		for (x = 0; x < 16; x++)
		{
			j = y*16 + x;
			byte = DINO[dino_dir][j];
			OLED_WR_Byte(byte, OLED_DATA);
		}
	}
} 

// ????????
void OLED_DrawCactus()
{
	char speed = 5;
	static int pos = 128;
	int start_x = 0;
	int length = sizeof(CACTUS_2)/2;

	unsigned int j=0;
	unsigned char x, y;
	unsigned char byte;

	if (pos + length <= 0)
	{
		oled_drawbmp_block_clear(0, 6, speed);
		pos = 128;
	}

	for(y=0; y<2; y++)
	{
		if(pos < 0)
		{
			start_x = -pos;
			OLED_Set_Pos(0, 6+y);
		}
		else
		{
			OLED_Set_Pos(pos, 6+y);
		}

		for (x = start_x; x < length; x++)
		{
			if (pos + x > 127) break;
			j = y*length + x;
			byte = CACTUS_2[j];
			OLED_WR_Byte(byte, OLED_DATA);
		}
	}
	oled_drawbmp_block_clear(pos + length, 6, speed); // ????
	pos = pos - speed;
}

// ?????????????
int OLED_DrawCactusRandom(unsigned char ver, unsigned char reset)
{
	char speed = 5;
	static int pos = 128;
	int start_x = 0;
	int length = 0;

	unsigned int i=0, j=0;
	unsigned char x, y;
	unsigned char byte;
	if (reset == 1)
	{
		pos = 128;
		oled_drawbmp_block_clear(0, 6, speed);
		return 128;
	}
	if (ver == 0) length = 8; //sizeof(CACTUS_1) / 2;
	else if (ver == 1) length = 16; //sizeof(CACTUS_2) / 2;
	else if (ver == 2 || ver == 3) length = 24;

	for(y=0; y<2; y++)
	{
		if(pos < 0)
		{
			start_x = -pos;
			OLED_Set_Pos(0, 6+y);
		}
		else
		{
			OLED_Set_Pos(pos, 6+y);
		}

		for (x = start_x; x < length; x++)
		{
			if (pos + x > 127) break;

			j = y*length + x;
			if (ver == 0) byte = CACTUS_1[j];
			else if (ver == 1) byte = CACTUS_2[j];
			else if(ver == 2) byte = CACTUS_3[j];
			else byte = CACTUS_4[j];
			OLED_WR_Byte(byte, OLED_DATA);
		}
	}

	oled_drawbmp_block_clear(pos + length, 6, speed);

	pos = pos - speed;
	return pos + speed;
}

// ???????
int OLED_DrawDinoJump(char reset)
{
	char speed_arr[] = {1, 1, 3, 3, 4, 4, 5, 6, 7};
	static char speed_idx = sizeof(speed_arr)-1;
	static int height = 0;
	static char dir = 0;
	//char speed = 4;

	unsigned int j=0;
	unsigned char x, y;
	char offset = 0;
	unsigned char byte;
	if(reset == 1)
	{
		height = 0;
		dir = 0;
		speed_idx = sizeof(speed_arr)-1;
		return 0;
	}
	if (dir==0)
	{
		height += speed_arr[speed_idx];
		speed_idx --;
		if (speed_idx<0) speed_idx = 0;
	}
	if (dir==1)
	{
		height -= speed_arr[speed_idx];
		speed_idx ++;
		if (speed_idx>sizeof(speed_arr)-1) speed_idx = sizeof(speed_arr)-1;
	}
	if(height >= 31)
	{
		dir = 1;
		height = 31;
	}
	if(height <= 0)
	{
		dir = 0;
		height = 0;
	}
	if(height <= 7) offset = 0;
	else if(height <= 15) offset = 1;
	else if(height <= 23) offset = 2;
	else if(height <= 31) offset = 3;
	else offset = 4;

	for(y=0; y<3; y++) // 4
	{
		OLED_Set_Pos(16, 5- offset + y);

		for (x = 0; x < 16; x++) // 32
		{
			j = y*16 + x; // 32
			byte = DINO_JUMP[height%8][j];
			OLED_WR_Byte(byte, OLED_DATA);
		}
	}
	if (dir == 0) oled_drawbmp_block_clear(16, 8- offset, 16);
	if (dir == 1) oled_drawbmp_block_clear(16, 4- offset, 16);
	return height;
}

// ????
void OLED_DrawRestart()
{
	unsigned int j=0;
	unsigned char x, y;
	unsigned char byte;
	//OLED_SetPos(0, 0);
	for (y = 2; y < 5; y++)
	{
		OLED_Set_Pos(52, y);
		for (x = 0; x < 24; x++)
		{
			byte = RESTART[j++];
			OLED_WR_Byte(byte, OLED_DATA);
		}
	}
	OLED_ShowString(10, 3, "GAME");
	OLED_ShowString(86, 3, "OVER");
}

// ????
void OLED_DrawCover()
{
	OLED_DrawBMPFast(COVER);
}

void OLED_DrawTeam()
{
	OLED_ShowString(2, 0, "????");
    OLED_ShowString(0, 2, "???");
	OLED_ShowString(0, 4, "???");
	OLED_ShowString(0, 6, "???");
}

// ??????
void OLED_DrawMean()
{
	OLED_ShowString(0, 0, "Tips");
	OLED_ShowString(0, 2, "Press 1 to jump");
	OLED_ShowString(0, 4, "Press 2 to restart");
	OLED_ShowString(0, 6, "Press 3 to exit");
}

/* 9.28 ���ΰ ���� oled�����˵� */
/********************  С�˵�   *******************/
void Menu1(void)//������Ϸ
{
	KeyNum=get_key_val();//�ض����ȡ���������룡����
	if(KeyNum==1)
		{
		mode=7;
		playflag=0;
		bmpflag=0;
		MenuShow=0;
		MenuSelect=0;
		menuclear=0;	
		OLED_Clear();
		}
		//��һ��Ϊ����
		OLED_ShowString_new(4,1,"6.",3,0);OLED_ShowMenuChinese(4,2,23,0);OLED_ShowMenuChinese(4,3,24,0);//�ػ�
		return;
}
void Menu2(void)//���ó�ʼ�ٶ�
{	KeyNum=get_key_val();//�ض����ȡ���������룡����
	OLED_ShowMenuChinese(1,1,4,0);OLED_ShowMenuChinese(1,2,5,0);OLED_ShowMenuChinese(1,3,6,0);OLED_ShowMenuChinese(1,4,7,0);//��ʼ�ٶ�
	OLED_ShowNum(3,8,begingtemp,1,3);
	if(KeyNum==2){begingtemp++;begingtemp%=10;beingspeed=begingtemp*3;};
	if(KeyNum==1){Key4++;if(Key4>1){mode=7;Key4=0;}OLED_Clear();}
}
void Menu3(void)//�����ٶ�����
{	KeyNum=get_key_val();//�ض����ȡ���������룡����
	OLED_ShowMenuChinese(1,1,8,0);OLED_ShowMenuChinese(1,2,9,0);OLED_ShowMenuChinese(1,3,10,0);OLED_ShowMenuChinese(1,4,11,0);
	OLED_ShowNum(3,8,speedtep,1,3);
	if(KeyNum==2){speedtep--;if(speedtep<=1)speedtep=1;speedmax=speedtep*4;}
	if(KeyNum==1){Key4++;if(Key4>1){mode=7;Key4=0;}OLED_Clear();}	
}
void Menu4(void)//����������
{	KeyNum=get_key_val();//�ض����ȡ���������룡����
	OLED_ShowMenuChinese(1,1,12,0);OLED_ShowMenuChinese(1,2,13,0);OLED_ShowMenuChinese(1,3,14,0);OLED_ShowMenuChinese(1,4,15,0);OLED_ShowMenuChinese(1,5,16,0);
	if(FMQswitch==0)
	{
		OLED_ShowString_new(3,7,"ON ",3,0);
	}
	else 
	OLED_ShowString_new(3,7,"OFF ",3,0);
	if(KeyNum==2){FMQswitch++;FMQswitch%=2;}
	if(KeyNum==1){Key4++;if(Key4>1){mode=7;Key4=0;}OLED_Clear();}	
}
void Menu5(void)//���㶯������
{	KeyNum=get_key_val();//�ض����ȡ���������룡����
	OLED_ShowMenuChinese(1,1,17,0);OLED_ShowMenuChinese(1,2,18,0);OLED_ShowMenuChinese(1,3,19,0);OLED_ShowMenuChinese(1,4,20,0);OLED_ShowMenuChinese(1,5,21,0);OLED_ShowMenuChinese(1,6,22,0);
	if(FMQswitch==0)
	{
		OLED_ShowString_new(3,7,"ON ",3,0);
	}
	else 
	{
	OLED_ShowString_new(3,7,"OFF",3,0);
	Settlement=~Settlement;
	}
	if(KeyNum==2){FMQswitch++;FMQswitch%=2;}
	if(KeyNum==1){Key4++;if(Key4>1){mode=7;Key4=0;}OLED_Clear();}	
}
void Menu6(void)//�ػ�
{
	//OLED_OFF();
}

/********************  ��˵�   *******************/
void Menu(void)
{
	KeyNum=0;
	while(get_key_val()){
		KeyNum=get_key_val();//�ض����ȡ���������룡����
	}

	if(KeyNum==1)
	{
		playflag=0;
		bmpflag=0;
	}
	if(menuclear==0)
	{
	OLED_Clear();menuclear++;
	}
	
	if(!MenuShow)
	{
		KeyNum=0;
		while(get_key_val()){
			KeyNum=get_key_val();//�ض����ȡ���������룡����
		}
		
		if(KeyNum==2)//�˵��»�
		{	
			MenuSelect++;
			MenuSelect%=6;
			OLED_Clear();
		}
		OLED_ShowChinese(1,4,0,0);//��
		OLED_ShowChinese(1,5,1,0);//��
		switch(MenuSelect)
		{
		case 0:if(MenuSelect==0){// ��ʾ��1���������������Ǹ���
								OLED_ShowString_new(2,1,"1.",3,1);OLED_ShowMenuChinese(2,2,0,1);OLED_ShowMenuChinese(2,3,1,1);OLED_ShowMenuChinese(2,4,2,1);OLED_ShowMenuChinese(2,5,3,1);//������Ϸ
								// ��ʾ "2." �Ǹ���
								OLED_ShowString_new(3,1,"2.",3,0);OLED_ShowMenuChinese(3,2,4,0);OLED_ShowMenuChinese(3,3,5,0);OLED_ShowMenuChinese(3,4,6,0);OLED_ShowMenuChinese(3,5,7,0);//��ʼ�ٶ�
								// ��ʾ "3." �Ǹ���
								OLED_ShowString_new(4,1,"3.",3,0);OLED_ShowMenuChinese(4,2,8,0);OLED_ShowMenuChinese(4,3,9,0);OLED_ShowMenuChinese(4,4,10,0);OLED_ShowMenuChinese(4,5,11,0);//�ٶ�����
								}
				// ��δѡ�д˲˵���ʱ
				else {OLED_ShowString_new(2,1,"1.",3,0);OLED_ShowMenuChinese(2,2,0,0);OLED_ShowMenuChinese(2,3,1,0);OLED_ShowMenuChinese(2,4,2,0);OLED_ShowMenuChinese(2,5,3,0);}break;//������Ϸ}
		case 1:if(MenuSelect==1){
								OLED_ShowString_new(2,1,"1.",3,0);OLED_ShowMenuChinese(2,2,0,0);OLED_ShowMenuChinese(2,3,1,0);OLED_ShowMenuChinese(2,4,2,0);OLED_ShowMenuChinese(2,5,3,0);//������Ϸ
								OLED_ShowString_new(3,1,"2.",3,1);OLED_ShowMenuChinese(3,2,4,1);OLED_ShowMenuChinese(3,3,5,1);OLED_ShowMenuChinese(3,4,6,1);OLED_ShowMenuChinese(3,5,7,1);//��ʼ�ٶ�
								OLED_ShowString_new(4,1,"3.",3,0);OLED_ShowMenuChinese(4,2,8,0);OLED_ShowMenuChinese(4,3,9,0);OLED_ShowMenuChinese(4,4,10,0);OLED_ShowMenuChinese(4,5,11,0);//�ٶ�����
								}
				else {OLED_ShowString_new(3,1,"2.",3,0);OLED_ShowMenuChinese(3,2,4,0);OLED_ShowMenuChinese(3,3,5,0);OLED_ShowMenuChinese(3,4,6,0);OLED_ShowMenuChinese(3,5,7,0);}break;//������Ϸ}
		case 2:if(MenuSelect==2){
								OLED_ShowString_new(2,1,"1.",3,0);OLED_ShowMenuChinese(2,2,0,0);OLED_ShowMenuChinese(2,3,1,0);OLED_ShowMenuChinese(2,4,2,0);OLED_ShowMenuChinese(2,5,3,0);//������Ϸ
								OLED_ShowString_new(3,1,"2.",3,0);OLED_ShowMenuChinese(3,2,4,0);OLED_ShowMenuChinese(3,3,5,0);OLED_ShowMenuChinese(3,4,6,0);OLED_ShowMenuChinese(3,5,7,0);//��ʼ�ٶ�
								OLED_ShowString_new(4,1,"3.",3,1);OLED_ShowMenuChinese(4,2,8,1);OLED_ShowMenuChinese(4,3,9,1);OLED_ShowMenuChinese(4,4,10,1);OLED_ShowMenuChinese(4,5,11,1);//�ٶ�����
								}
				else {OLED_ShowString_new(4,1,"3.",3,0);OLED_ShowMenuChinese(4,2,8,0);OLED_ShowMenuChinese(4,3,9,0);OLED_ShowMenuChinese(4,4,10,0);OLED_ShowMenuChinese(4,5,11,0);};break;//������Ϸ}
		/*--------------------- ��ҳ -----------------*/		
		case 3:if(MenuSelect==3){
								OLED_ShowString_new(2,1,"4.",3,1);OLED_ShowMenuChinese(2,2,12,1);OLED_ShowMenuChinese(2,3,13,1);OLED_ShowMenuChinese(2,4,14,1);OLED_ShowMenuChinese(2,5,15,1);OLED_ShowMenuChinese(2,6,16,1);//����������
								OLED_ShowString_new(3,1,"5.",3,0);OLED_ShowMenuChinese(3,2,17,0);OLED_ShowMenuChinese(3,3,18,0);OLED_ShowMenuChinese(3,4,19,0);OLED_ShowMenuChinese(3,5,20,0);OLED_ShowMenuChinese(3,6,21,0);OLED_ShowMenuChinese(3,7,22,0);//���㶯������
								OLED_ShowString_new(4,1,"6.",3,0);OLED_ShowMenuChinese(4,2,23,0);OLED_ShowMenuChinese(4,3,24,0);//�ػ�
								}
				else {OLED_ShowString_new(2,1,"4.",3,0);OLED_ShowMenuChinese(2,2,12,0);OLED_ShowMenuChinese(2,3,13,0);OLED_ShowMenuChinese(2,2,14,0);OLED_ShowMenuChinese(2,3,15,1);OLED_ShowMenuChinese(2,3,16,0);}break;
		case 4:if(MenuSelect==4){
								OLED_ShowString_new(2,1,"4.",3,0);OLED_ShowMenuChinese(2,2,12,0);OLED_ShowMenuChinese(2,3,13,0);OLED_ShowMenuChinese(2,4,14,0);OLED_ShowMenuChinese(2,5,15,0);OLED_ShowMenuChinese(2,6,16,0);//����������
								OLED_ShowString_new(3,1,"5.",3,1);OLED_ShowMenuChinese(3,2,17,1);OLED_ShowMenuChinese(3,3,18,1);OLED_ShowMenuChinese(3,4,19,1);OLED_ShowMenuChinese(3,5,20,1);OLED_ShowMenuChinese(3,6,21,1);OLED_ShowMenuChinese(3,7,22,1);//���㶯������
								OLED_ShowString_new(4,1,"6.",3,0);OLED_ShowMenuChinese(4,2,23,0);OLED_ShowMenuChinese(4,3,24,0);//�ػ�
								}
				else {OLED_ShowString_new(3,1,"5.",3,0);OLED_ShowMenuChinese(3,2,17,0);OLED_ShowMenuChinese(3,3,18,0);OLED_ShowMenuChinese(3,4,19,0);OLED_ShowMenuChinese(3,5,20,0);OLED_ShowMenuChinese(3,6,21,0);OLED_ShowMenuChinese(3,7,22,0);}break;//���㶯������
		case 5:if(MenuSelect==5){
								OLED_ShowString_new(2,1,"4.",3,0);OLED_ShowMenuChinese(2,2,12,0);OLED_ShowMenuChinese(2,3,13,0);OLED_ShowMenuChinese(2,4,14,0);OLED_ShowMenuChinese(2,5,15,0);OLED_ShowMenuChinese(2,6,16,0);//����������
								OLED_ShowString_new(3,1,"5.",3,0);OLED_ShowMenuChinese(3,2,17,0);OLED_ShowMenuChinese(3,3,18,0);OLED_ShowMenuChinese(3,4,19,0);OLED_ShowMenuChinese(3,5,20,0);OLED_ShowMenuChinese(3,6,21,0);OLED_ShowMenuChinese(3,7,22,0);//���㶯������
								OLED_ShowString_new(4,1,"6.",3,1);OLED_ShowMenuChinese(4,2,23,1);OLED_ShowMenuChinese(4,3,24,1);//�ػ�
								}
				else {OLED_ShowString_new(4,1,"6.",3,0);OLED_ShowMenuChinese(4,2,23,0);OLED_ShowMenuChinese(4,3,24,0);}break;//�ػ�
		}
	}
//}             /*      ���}���ţ�ɾ��       */

		KeyNum=0;
		while(get_key_val()){
			KeyNum=get_key_val();//�ض����ȡ���������룡����
		}
		
		if(KeyNum==1)//ѡ�иò˵�
		{	
			if(ClearF==0)
			{
				ClearF++;
				OLED_Clear();
			}
			switch(MenuSelect)
			{
				case 0:mode=1;break;
				case 1:mode=2;break;
				case 2:mode=3;break;
				case 3:mode=4;break;
				case 4:mode=5;break;
				case 5:mode=6;break;
			}
		}		
				switch(mode)
			{
				case 1:Menu1();MenuShow=1;break;
				case 2:Menu2();MenuShow=1;break;
				case 3:Menu3();MenuShow=1;break;
				case 4:Menu4();MenuShow=1;break;
				case 5:Menu5();MenuShow=1;break;
				case 6:Menu6();MenuShow=1;break;
				case 7:MenuShow=0;break;
				default :break;
			}
	//}		
}
/*******************************************************************************/

// ????
void OLED_DrawPoster()
{
	OLED_ShowString(0, 0, "Dino Jump");
	OLED_ShowCHinese(20, 20, 20);//?????
}


void Port_init(void)
{

 PORTB |= 0x06;
 DDRB  |= 0x06;
 PORTG |= 0x04;
 DDRG  |= 0x04;
 PORTL |= 0x48;
 DDRL  |= 0x48;
}
//SSD1306
void OLED_Init(void)
{
	Port_init();
	OLED_RST_Set();
	delay_ms(100);
	OLED_RST_Clr();

	delay_ms(100);

	OLED_RST_Set();

	OLED_WR_Byte(0xAE, OLED_CMD); //--turn off oled panel
	OLED_WR_Byte(0x00, OLED_CMD); //---set low column address
	OLED_WR_Byte(0x10, OLED_CMD); //---set high column address
	OLED_WR_Byte(0x40, OLED_CMD); //--set start line address  Set Mapping RAM Display Start Line (0x00~0x3F)
	OLED_WR_Byte(0x81, OLED_CMD); //--set contrast control register
	OLED_WR_Byte(0xCF, OLED_CMD); // Set SEG Output Current Brightness
	OLED_WR_Byte(0xA1, OLED_CMD); //--Set SEG/Column Mapping      0xa0???? 0xa1??
	OLED_WR_Byte(0xC8, OLED_CMD); // Set COM/Row Scan Direction    0xc0???? 0xc8??
	OLED_WR_Byte(0xA6, OLED_CMD); //--set normal display
	OLED_WR_Byte(0xA8, OLED_CMD); //--set multiplex ratio(1 to 64)
	OLED_WR_Byte(0x3f, OLED_CMD); //--1/64 duty
	OLED_WR_Byte(0xD3, OLED_CMD); //-set display offset	Shift Mapping RAM Counter (0x00~0x3F)
	OLED_WR_Byte(0x00, OLED_CMD); //-not offset
	OLED_WR_Byte(0xd5, OLED_CMD); //--set display clock divide ratio/oscillator frequency
	OLED_WR_Byte(0x80, OLED_CMD); //--set divide ratio, Set Clock as 100 Frames/Sec
	OLED_WR_Byte(0xD9, OLED_CMD); //--set pre-charge period
	OLED_WR_Byte(0xF1, OLED_CMD); // Set Pre-Charge as 15 Clocks & Discharge as 1 Clock
	OLED_WR_Byte(0xDA, OLED_CMD); //--set com pins hardware configuration
	OLED_WR_Byte(0x12, OLED_CMD);
	OLED_WR_Byte(0xDB, OLED_CMD); //--set vcomh
	OLED_WR_Byte(0x40, OLED_CMD); // Set VCOM Deselect Level
	OLED_WR_Byte(0x20, OLED_CMD); //-Set Page Addressing Mode (0x00/0x01/0x02)
	OLED_WR_Byte(0x02, OLED_CMD); //
	OLED_WR_Byte(0x8D, OLED_CMD); //--set Charge Pump enable/disable
	OLED_WR_Byte(0x14, OLED_CMD); //--set(0x10) disable
	OLED_WR_Byte(0xA4, OLED_CMD); // Disable Entire Display On (0xa4/0xa5)
	OLED_WR_Byte(0xA6, OLED_CMD); // Disable Inverse Display On (0xa6/a7)
	OLED_WR_Byte(0xAF, OLED_CMD); //--turn on oled panel

	OLED_WR_Byte(0xAF, OLED_CMD); /*display ON*/
	OLED_Clear();
	OLED_Set_Pos(0, 0);
}

