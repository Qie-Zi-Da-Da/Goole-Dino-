CC = iccavr
LIB = ilibw
CFLAGS =  -I.\source -e -D__ICC_VERSION=722 -D_EE_EXTIO -DATMega2560  -l -g -MExtended -MLongJump -MHasMul -MEnhanced -Wf-use_elpm -Wf-const_is_flash -DCONST="" 
ASFLAGS = $(CFLAGS) 
LFLAGS =  -g -e:0x40000 -xcall -ucrtatmega.o -bfunc_lit:0xe4.0x40000 -dram_end:0x21ff -bdata:0x200.0x21ff -dhwstk_size:30 -beeprom:0.4096 -fihx_coff -S2
FILES = main.o i2c.o timer.o board.o key.o queue.o OLEDWork.o hc595.o 

GPIO:	$(FILES)
	$(CC) -o GPIO $(LFLAGS) @GPIO.lk   -lcatm256
main.o: D:\PROGRA~1\iccv7avr\include\iom2560v.h D:\PROGRA~1\iccv7avr\include\_iom640to2561v.h D:\PROGRA~1\iccv7avr\include\macros.h D:\PROGRA~1\iccv7avr\include\AVRdef.h D:\PROGRA~1\iccv7avr\include\stdio.h D:\PROGRA~1\iccv7avr\include\stdarg.h D:\PROGRA~1\iccv7avr\include\_const.h .\..\source\timer.h .\..\source\board.h .\..\source\i2c.h .\..\source\key.h .\..\source\OLEDWork.h .\..\source\Delay.h .\..\source\lcd.h .\..\source\test.h .\..\source\hc595.h
main.o:	..\source\main.c
	$(CC) -c $(CFLAGS) ..\source\main.c
i2c.o: D:\PROGRA~1\iccv7avr\include\iom2560v.h D:\PROGRA~1\iccv7avr\include\_iom640to2561v.h D:\PROGRA~1\iccv7avr\include\stdio.h D:\PROGRA~1\iccv7avr\include\stdarg.h D:\PROGRA~1\iccv7avr\include\_const.h D:\PROGRA~1\iccv7avr\include\ASSERT.H .\..\source\board.h D:\PROGRA~1\iccv7avr\include\macros.h D:\PROGRA~1\iccv7avr\include\AVRdef.h
i2c.o:	..\source\i2c.c
	$(CC) -c $(CFLAGS) ..\source\i2c.c
timer.o: D:\PROGRA~1\iccv7avr\include\iom2560v.h D:\PROGRA~1\iccv7avr\include\_iom640to2561v.h D:\PROGRA~1\iccv7avr\include\macros.h D:\PROGRA~1\iccv7avr\include\AVRdef.h
timer.o:	..\source\timer.c
	$(CC) -c $(CFLAGS) ..\source\timer.c
board.o: D:\PROGRA~1\iccv7avr\include\iom2560v.h D:\PROGRA~1\iccv7avr\include\_iom640to2561v.h D:\PROGRA~1\iccv7avr\include\stdio.h D:\PROGRA~1\iccv7avr\include\stdarg.h D:\PROGRA~1\iccv7avr\include\_const.h .\..\source\board.h D:\PROGRA~1\iccv7avr\include\macros.h D:\PROGRA~1\iccv7avr\include\AVRdef.h .\..\source\timer.h .\..\source\i2c.h D:\PROGRA~1\iccv7avr\include\ASSERT.H .\..\source\key.h .\..\source\queue.h
board.o:	..\source\board.c
	$(CC) -c $(CFLAGS) ..\source\board.c
key.o: .\..\source\board.h D:\PROGRA~1\iccv7avr\include\iom2560v.h D:\PROGRA~1\iccv7avr\include\_iom640to2561v.h D:\PROGRA~1\iccv7avr\include\macros.h D:\PROGRA~1\iccv7avr\include\AVRdef.h .\..\source\key.h .\..\source\timer.h
key.o:	..\source\key.c
	$(CC) -c $(CFLAGS) ..\source\key.c
queue.o: .\..\source\board.h D:\PROGRA~1\iccv7avr\include\iom2560v.h D:\PROGRA~1\iccv7avr\include\_iom640to2561v.h D:\PROGRA~1\iccv7avr\include\macros.h D:\PROGRA~1\iccv7avr\include\AVRdef.h .\..\source\queue.h
queue.o:	..\source\queue.c
	$(CC) -c $(CFLAGS) ..\source\queue.c
OLEDWork.o: .\..\source\OLEDWork.h D:\PROGRA~1\iccv7avr\include\iom2560v.h D:\PROGRA~1\iccv7avr\include\_iom640to2561v.h D:\PROGRA~1\iccv7avr\include\macros.h D:\PROGRA~1\iccv7avr\include\AVRdef.h .\..\source\board.h .\..\source\oldfont.h .\..\source\Delay.h D:\PROGRA~1\iccv7avr\include\time.h .\..\source\key.h .\..\source\queue.h
OLEDWork.o:	..\source\OLEDWork.c
	$(CC) -c $(CFLAGS) ..\source\OLEDWork.c
hc595.o: .\..\source\hc595.h .\..\source\board.h D:\PROGRA~1\iccv7avr\include\iom2560v.h D:\PROGRA~1\iccv7avr\include\_iom640to2561v.h D:\PROGRA~1\iccv7avr\include\macros.h D:\PROGRA~1\iccv7avr\include\AVRdef.h
hc595.o:	..\source\hc595.c
	$(CC) -c $(CFLAGS) ..\source\hc595.c
